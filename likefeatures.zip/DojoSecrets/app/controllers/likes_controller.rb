class LikesController < ApplicationController
  def create
  end

  def destroy
  end
end
